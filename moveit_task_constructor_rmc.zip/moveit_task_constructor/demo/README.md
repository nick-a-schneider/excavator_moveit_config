# moveit_task_constructor_demo

Description: A simple pick & place demo using MoveIt Task Constructor. This uses the Panda from Franka Emika

Developed by Henning Kayser & Simon Goldstein at [PickNik Consulting](http://picknik.ai/)

## Run

Run demo

    roslaunch moveit_task_constructor_demo demo.launch
